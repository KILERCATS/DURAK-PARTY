const $ = id=>document.getElementById(id);
const socket=io();let state=null,roomCode='',token='',selected=null,defendTarget=null,localOrder=[];
const RED=['♥','♦'];
const rankOrder={'6':0,'7':1,'8':2,'9':3,'10':4,'В':5,'Д':6,'К':7,'Т':8};
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2800)}
function name(){return $('name').value.trim()||'Игрок'}
function persist(){localStorage.setItem('durak-seat',JSON.stringify({code:roomCode,token}));localStorage.setItem('durak-name',name());}
$('name').value=localStorage.getItem('durak-name')||'';
$('create').onclick=()=>socket.emit('create',{name:name()});
$('toggleJoin').onclick=()=>{$('joinControls').hidden=!$('joinControls').hidden};
$('join').onclick=()=>socket.emit('join',{code:$('roomCode').value,name:name()});
$('copy').onclick=async()=>{const url=location.origin+'/?room='+roomCode;try{await navigator.clipboard.writeText(url);toast('Ссылка скопирована!')}catch(e){prompt('Скопируй ссылку:',url)}};
$('take').onclick=()=>socket.emit('resolve',{code:roomCode,action:'take'});
$('beat').onclick=()=>socket.emit('resolve',{code:roomCode,action:'beat'});
$('restart').onclick=()=>socket.emit('restart',{code:roomCode});
$('sort').onclick=()=>{if(!state)return;localOrder=[...state.hand].sort((a,b)=> (a.suit===state.trump?4:['♣','♦','♥','♠'].indexOf(a.suit))-(b.suit===state.trump?4:['♣','♦','♥','♠'].indexOf(b.suit))||rankOrder[a.rank]-rankOrder[b.rank]).map(c=>c.id);render();};
socket.on('connect',()=>{$('connection').textContent='● На связи';const saved=JSON.parse(localStorage.getItem('durak-seat')||'null');if(saved?.code&&saved.token)socket.emit('join',{...saved,name:name()});else{const c=new URLSearchParams(location.search).get('room');if(c){$('roomCode').value=c;$('joinControls').hidden=false;}}});
socket.on('disconnect',()=>{$('connection').textContent='● Переподключение…'});
socket.on('joined',data=>{roomCode=data.code;token=data.token;persist();history.replaceState(null,'','/?room='+roomCode);$('lobby').hidden=true;$('game').hidden=false;});
socket.on('errorMessage',msg=>{toast(msg);if(!state){localStorage.removeItem('durak-seat');$('lobby').hidden=false;$('game').hidden=true;}});
socket.on('state',s=>{if(s.code!==roomCode)return;state=s;selected=null;defendTarget=null;const ids=s.hand.map(c=>c.id);localOrder=[...localOrder.filter(id=>ids.includes(id)),...ids.filter(id=>!localOrder.includes(id))];render();});
function cardElement(c,additional=''){
 const el=document.createElement('div');el.className='card '+(RED.includes(c.suit)?'red ':'')+additional;el.dataset.id=c.id;
 el.innerHTML=`<div class="corner">${c.rank}<div>${c.suit}</div></div><div class="symbol">${c.suit}</div><div class="corner bottom">${c.rank}<div>${c.suit}</div></div>`;return el;
}
function playCard(id){if(!state?.started||state.finished)return;const me=state.me;
 if(me===state.defender){const uncovered=state.table.filter(t=>!t.defense);if(!uncovered.length)return toast('Сначала дождись атаки');if(!defendTarget&&uncovered.length>1){selected=id;render();return toast('Выбери карту атаки на столе, которую хочешь покрыть');}socket.emit('play',{code:roomCode,id,defendId:defendTarget||uncovered[0].attack.id});}
 else socket.emit('play',{code:roomCode,id});}
function render(){if(!state)return;let s=state;
 $('code').textContent=s.code;$('status').textContent=s.finished?'Игра закончена':s.players.length<2?'Ожидаем друга…':s.message;
 $('opponentName').textContent=s.players[1-s.me]?.name||'Друг';$('opponentInfo').textContent=s.players[1-s.me]?(s.players[1-s.me].online?'В сети • ':'Отключился • ')+s.players[1-s.me].count+' карт':'Ещё не подключился';
 $('myName').textContent=s.players[s.me].name;$('myCount').textContent=s.hand.length+' карт';
 $('opponentCards').replaceChildren();for(let i=0;i<Math.min(s.players[1-s.me]?.count||0,12);i++){const e=document.createElement('div');e.className='back-mini';$('opponentCards').append(e)}
 $('trump').textContent=s.trump||'—';$('trump').style.color=RED.includes(s.trump)?'#ff7898':'white';$('deckCount').textContent=s.deckCount+' в колоде';$('deck').style.visibility=s.deckCount?'visible':'hidden';
 $('battle').replaceChildren();if(!s.table.length){const el=document.createElement('div');el.className='placeholder';el.textContent=s.started?'Стол пуст — время ходить':'Ждём второго игрока';$('battle').append(el)}
 s.table.forEach(t=>{const p=document.createElement('div');p.className='pair';const attack=cardElement(t.attack,'attack'+(defendTarget===t.attack.id?' target':''));attack.onclick=()=>{if(s.me!==s.defender||t.defense)return;defendTarget=t.attack.id;if(selected)playCard(selected);else render();};p.append(attack);if(t.defense)p.append(cardElement(t.defense,'defense'));$('battle').append(p)});
 $('hint').textContent=s.finished?(s.winner==='Ничья'?'Ничья! 🏁':'Победитель: '+s.winner+' 🏆'):!s.started?'Отправь ссылку другу — игра начнётся автоматически':s.me===s.attacker?'Твой ход: выбери карту, чтобы атаковать или подкинуть':'Ты защищаешься: выбери карту для отбоя';
 $('take').hidden=!(s.started&&!s.finished&&s.me===s.defender&&s.table.length);
 $('beat').hidden=!(s.started&&!s.finished&&s.me===s.attacker&&s.table.length&&s.table.every(t=>t.defense));
 $('restart').hidden=!s.finished;
 const hand=$('hand');hand.replaceChildren();const cards=localOrder.map(id=>s.hand.find(c=>c.id===id)).filter(Boolean);
 cards.forEach(c=>{const el=cardElement(c,selected===c.id?'selected':'');el.draggable=true;
 el.onclick=()=>{if(el.dataset.justDragged==='true')return;playCard(c.id)};
 el.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/plain',c.id);e.dataTransfer.effectAllowed='move';el.classList.add('dragging')});
 el.addEventListener('dragend',()=>el.classList.remove('dragging'));
 el.addEventListener('dragover',e=>e.preventDefault());el.addEventListener('drop',e=>{e.preventDefault();reorder(e.dataTransfer.getData('text/plain'),c.id)});
 let sx,sy;el.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;});
 el.addEventListener('pointerup',e=>{if(sx==null||Math.hypot(e.clientX-sx,e.clientY-sy)<20)return;const hit=document.elementFromPoint(e.clientX,e.clientY)?.closest('.hand .card');if(hit&&hit!==el){reorder(c.id,hit.dataset.id);el.dataset.justDragged='true';setTimeout(()=>{delete el.dataset.justDragged},80)}});
 hand.append(el);});}
function reorder(a,b){if(!a||!b||a===b)return;const old=localOrder.indexOf(a),next=localOrder.indexOf(b);if(old<0||next<0)return;localOrder.splice(old,1);localOrder.splice(next,0,a);render();}
